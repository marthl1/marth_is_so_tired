package org.example.functions;

import java.lang.reflect.InvocationTargetException;

public interface ImagesOperations {
    float[] execute(float[] rgb) throws InvocationTargetException, IllegalAccessException;
}

